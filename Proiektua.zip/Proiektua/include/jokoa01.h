// 2024-2025 ikasturtea

/*---------------------------------------------------------------------------------
jokoa01
---------------------------------------------------------------------------------*/
void jokoa01();
extern int Options();
extern int Menu(DATA* data);
extern int jokoa();
extern int Tutorial();
extern int egunarenBukaera();

/***********************2024-2025*******************************/

