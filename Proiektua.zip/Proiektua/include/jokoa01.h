// 2024-2025 ikasturtea

/*---------------------------------------------------------------------------------
jokoa01
---------------------------------------------------------------------------------*/
#ifndef JOKOA1_H
#define JOKOA1_H

void jokoa01();
extern int Options();
extern int Menu(DATA* data);
extern int jokoa();
extern int Tutorial();
extern int egunarenBukaera();
extern int eguna;
#endif
/***********************2024-2025*******************************/

