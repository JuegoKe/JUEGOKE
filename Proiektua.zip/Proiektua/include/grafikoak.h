// 2024-2025 ikasturtea

/* Bideo sistemaren definizioa */
#ifndef GRAFIKOAK_H
#define GRAFIKOAK_H

extern void hasieratuBideoa();
extern void GrafikoakHasieratu();
extern void hasieratuFondoak();


/* Spriteen memoria hasieratu */
extern void initSpriteMem();

extern void HasieratuGrafikoakSpriteak();
#endif
/***********************2024-2025*******************************/

