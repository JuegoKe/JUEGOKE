// 2024-2025 ikasturtea

/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiAtea();
extern void erakutsiAteaIrekita();
extern void erakutsiMenua();
extern void erakutsiPrueba();
extern void erakutsiAtzealdea();
/***********************2024-2025*******************************/

