#ifndef FONDOAK_H
#define FONDOAK_H



extern void erakutsiMenua();
extern void erakutsiPrueba();
extern void erakutsiTutoPag2();
extern void erakutsiTutoPag1();
extern void erakutsiPertsonaia(int i);
extern void pertsonaiakInizializatu();
extern void erakutsiDNI();
extern void erakutsiLISTA();
#endif
/***********************2024-2025*******************************/

