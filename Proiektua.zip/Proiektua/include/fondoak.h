// 2024-2025 ikasturtea

/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiAtea();
extern void erakutsiAteaIrekita();
extern void erakutsiMenua();
extern void erakutsiPrueba();
extern void erakutsiAtzealdea();
extern void erakutsiTutoPag2();
extern void erakutsiTutoPag1();
extern void erakutsiPertsonaia(int i);
extern void pertsonaiakInizializatu();
/***********************2024-2025*******************************/

