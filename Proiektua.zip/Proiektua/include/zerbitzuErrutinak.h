// 2024-2025 ikasturtea

/*-------------------------------------
zerbitzuErrutinak.h
-------------------------------------*/

extern void tekEten ();
extern void tenpEten();
extern void etenZerbErrutEzarri();
extern int save();
extern int load();
extern void clearBackground(int bgId);
/***********************2024-2025*******************************/

