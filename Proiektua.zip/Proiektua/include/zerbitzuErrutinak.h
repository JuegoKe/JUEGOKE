// 2024-2025 ikasturtea

/*-------------------------------------
zerbitzuErrutinak.h
-------------------------------------*/
#ifndef ZERBITZUERRUTINAK_H
#define ZERBITZUERRUTINAK_H




extern void tekEten ();
extern void tenpEten();
extern void etenZerbErrutEzarri();
extern int save();
extern int load();
extern void clearBackground(int bgId);
extern void hasieratuEguna();
extern NAN sortuDNIBerriBat();
extern int randenrango(int min, int max);
void listakEgin();
void erroreakJARRI();
extern void sartuBetListan(char izena[20], char abizena[20]);
extern NAN dni[NUM_MAX_PEOPLE];
extern void printLista();
extern void printDNI(int i);
/***********************2024-2025*******************************/
#endif
