// 2024-2025 ikasturtea

/*---------------------------------------------------------------------------------
Hemen bideo sistemaren definizioa baino ez dugu egiten, beste EZER EZ DA IKUTU BEHAR

Kode hau garatu da dovotoren "Simple sprite demo" adibidean eta Jaeden Ameronen beste
adibide batean oinarrituta.
---------------------------------------------------------------------------------*/

#include <nds.h> 		// NDS-rako garatuta dagoen liburutegia
#include <stdio.h>		// C-ko liburutegi estandarra sarrera eta irteerako funtzioak definitzen dituena
#include <stdlib.h>		// C-ko liburutegi estandarra memoria erreserbak eta zenbaki bihurketak egiteko
#include <unistd.h>		// Sistema eragileen arteko bateragarritasuna ziurtatzeko liburutegia
#include "grafikoak.h"
#include "spriteak.h"
#include "fondoak.h"
#include "grafikoak.h"
#include "Atea.h"
#include "AteaIrekita.h"
#include "Atea2.h"
#include "MainMenu.h"
PrintConsole topScreen;
int bg3Sub;



/* ---- ZATI HAU EZ DA ALDATU BEHAR ---- */
/* ----  FONDOEN KONFIGURAZIOA DA   ---- */
/* ----     HEMENDIK HASITA         ---- */

/* Fondo sistema konfiguratzeko prozedura */


/* ----       HONAINO       ---- */



// Supongamos que tienes los datos de AteaBitmap (generados por GRIT)
void hasieratuBideoa() {
    vramSetBankA(VRAM_A_MAIN_BG); // Fondo bitmap en main engine (BG3)
    vramSetBankC(VRAM_C_SUB_BG);  // Fondo de texto en sub-engine (BG0 y BG3)

    videoSetMode(MODE_5_2D | DISPLAY_BG3_ACTIVE);
    videoSetModeSub(MODE_0_2D | DISPLAY_BG0_ACTIVE | DISPLAY_BG3_ACTIVE);
}

void hasieratuKonsola() {
    topScreen = *consoleInit(0, 0, BgType_Text4bpp, BgSize_T_256x256, 4, 0, false, true);
   
    // Configurar paleta:
    // Índice 0: transparente (necesita el bit de transparencia activado)
    BG_PALETTE_SUB[0] = RGB15(0,0,0) | BIT(15); // Color 0 = transparente
    BG_PALETTE_SUB[1] = RGB15(31,31,31);       // Texto blanco
    
    // Configurar el registro de control para habilitar transparencia
    //REG_BG0CNT_SUB = BG_TILE_BASE(0) | BG_MAP_BASE(2) | BG_PRIORITY(0) | BG_WRAP_OFF;
   
   
    consoleSelect(&topScreen);
    consoleClear();
}

void GrafikoakHasieratu() {
    powerOn(POWER_ALL_2D);
    hasieratuBideoa();
}

void HasieratuGrafikoakSpriteak() {
    GrafikoakHasieratu();
    hasieratuFondoak();
    hasieratuKonsola();
}

void hasieratuFondoak() {
    // Fondo BG3 del main engine (bitmap)
    REG_BG3CNT = BG_BMP16_256x256 | BG_BMP_BASE(0) | BG_PRIORITY(3);
    REG_BG3PA = 1 << 8;
    REG_BG3PB = 0;
    REG_BG3PC = 0;
    REG_BG3PD = 1 << 8;
    REG_BG3X = 0;
    REG_BG3Y = 0;

    //REG_BG3CNT_SUB = BG_BMP16_256x256 | BG_BMP_BASE(0) | BG_PRIORITY(1);
    REG_BG3PA_SUB = 1 << 8;
    REG_BG3PB_SUB = 0;
    REG_BG3PC_SUB = 0;
    REG_BG3PD_SUB = 1 << 8;
    REG_BG3X_SUB = 0;
    REG_BG3Y_SUB = 0;

    // Fondo BG3 del sub-engine (texto)
    //int bg = bgInit(3, BgType_Bmp16, BgSize_B16_256x256, 1,0);
    
    REG_BG3CNT_SUB = BG_TILE_BASE(1) | BG_MAP_BASE(0) | BG_PRIORITY(1); // Prioridad 1 (más baja)
}








/***********************2024-2025*******************************/

