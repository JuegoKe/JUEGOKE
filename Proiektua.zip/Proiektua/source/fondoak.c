// 2024-2025 ikasturtea

/*---------------------------------------------------------------------------------
Kode hau garatu da dovotoren "Simple sprite demo" adibidean eta Jaeden Ameronen beste
adibide batean oinarrituta.
---------------------------------------------------------------------------------*/

#include <nds.h> 		// NDS-rako garatuta dagoen liburutegia
#include <stdio.h>		// C-ko liburutegi estandarra sarrera eta irteerako funtzioak definitzen dituena
#include <stdlib.h>		// C-ko liburutegi estandarra memoria erreserbak eta zenbaki bihurketak egiteko
#include <unistd.h>		// Sistema eragileen arteko bateragarritasuna ziurtatzeko liburutegia

/* Fondo desberdinak erakutsi nahi izango baditugu, hemen fondo bakoitzaren burukoa (.h fitxategia) gehitu behar da. Buruko horiek
automatikoki sortzen dira, konpilatzerako garaian, baina horretarako gogoratu behar da */

#include "fondoak.h"
#include "grafikoak.h"
#include "Atea.h"
#include "AteaIrekita.h"
#include "Atea2.h"
#include "MainMenu.h"
#include "TutoPag1.h"
#include "TutoPag2.h"
#include "definizioak.h"
#include "vaca.h"
#include "PabloEscobar.h"
#include "CarmendeMairena.h"
#include "Oyarzabal.h"
#include "KimJonUn.h"
#include "Darius.h"
#include "DuquesadeAlba.h"
#include "Maeb.h"


/* Irudiak memorian kopiatzeko DMA kanala aukeratu (3.a) */
static const int DMA_CHANNEL = 3;

/* Pantailaratu nahi den grafiko bakoitzerako horrelako prozedura bat idatzi behar da */
IMAGE images[NUM_IMAGES];


void erakutsiAtea() {
	
	dmaCopyHalfWords(DMA_CHANNEL,
                     AteaBitmap, // Automatikoki sortzen den aldagaia
                     (uint16 *)BG_BMP_RAM(0), // Fondo nagusiaren helbidea
                     AteaBitmapLen); // Luzera (bytetan); automatikoki sortzen den aldagaia
}

void erakutsiAteaIrekita() {
		
    dmaCopyHalfWords(DMA_CHANNEL,
                     AteaIrekitaBitmap, // Automatikoki sortzen den aldagaia
                     (uint16 *)BG_BMP_RAM(0), // Fondo nagusiaren helbidea
                     AteaIrekitaBitmapLen); // Luzera (bytetan); automatikoki sortzen den aldagaia
}



void erakutsiTutoPag1() {
		
    dmaCopy(TutoPag1Tiles, bgGetGfxPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), TutoPag1TilesLen);
    dmaCopy(TutoPag1Map, bgGetMapPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), TutoPag1MapLen);
    
    // Copiar la paleta completa sin desplazamiento
    dmaCopy(TutoPag1Pal, BG_PALETTE_SUB, TutoPag1PalLen);
}

void erakutsiTutoPag2() {
		
    dmaCopy(TutoPag2Tiles, bgGetGfxPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), TutoPag2TilesLen);
    dmaCopy(TutoPag2Map, bgGetMapPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), TutoPag2MapLen);
    
    // Copiar la paleta completa sin desplazamiento
    dmaCopy(TutoPag2Pal, BG_PALETTE_SUB, TutoPag2PalLen);
}

void erakutsiMenua() {
    // Fondo bitmap para el main engine (pantalla superior)

    // Fondo de texto para el sub-engine (pantalla inferior)
    dmaCopy(MainMenuTiles, bgGetGfxPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), MainMenuTilesLen);
    dmaCopy(MainMenuMap, bgGetMapPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), MainMenuMapLen);
    
    // Copiar la paleta completa sin desplazamiento
    dmaCopy(MainMenuPal, BG_PALETTE_SUB, MainMenuPalLen);


    // Asegurarse de que el índice 0 sea transparente y el índice 1 sea blanco para el texto
    //BG_PALETTE_SUB[0] = RGB15(0,0,0) | BIT(15); // Transparente
    //BG_PALETTE_SUB[1] = RGB15(31,31,31); // Blanco para el texto
}

void erakutsiAtzealdea() {
    // Fondo bitmap para el main engine (pantalla superior)

    // Fondo de texto para el sub-engine (pantalla inferior)
    dmaCopy(Atea2Tiles, bgGetGfxPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), Atea2TilesLen);
    dmaCopy(Atea2Map, bgGetMapPtr(bgInitSub(3, BgType_Text8bpp, BgSize_T_256x256, 5,1)), Atea2MapLen);
    
    // Copiar la paleta completa sin desplazamiento
    dmaCopy(Atea2Pal, BG_PALETTE_SUB, Atea2PalLen);


    // Asegurarse de que el índice 0 sea transparente y el índice 1 sea blanco para el texto
    //BG_PALETTE_SUB[0] = RGB15(0,0,0) | BIT(15); // Transparente
    //BG_PALETTE_SUB[1] = RGB15(31,31,31); // Blanco para el texto
}

void pertsonaiakInizializatu()
{
    images[0].bitMap = CarmendeMairenaBitmap;
    images[0].bitMapLen = CarmendeMairenaBitmapLen;

    images[1].bitMap = DariusBitmap;
    images[1].bitMapLen = DariusBitmapLen;

    images[2].bitMap = DuquesadeAlbaBitmap;
    images[2].bitMapLen = DuquesadeAlbaBitmapLen;

    images[3].bitMap = KimJonUnBitmap;
    images[3].bitMapLen = KimJonUnBitmapLen;

    images[4].bitMap = MaebBitmap;
    images[4].bitMapLen = MaebBitmapLen;

    images[5].bitMap = OyarzabalBitmap;
    images[5].bitMapLen = OyarzabalBitmapLen;

    images[6].bitMap = PabloEscobarBitmap;
    images[6].bitMapLen = PabloEscobarBitmapLen;

    images[7].bitMap = vacaBitmap;
    images[7].bitMapLen = vacaBitmapLen;
}

void erakutsiPertsonaia(int i)
{
    if(i < NUM_IMAGES)
    {
    dmaCopyHalfWords(DMA_CHANNEL,
        images[i].bitMap, // Automatikoki sortzen den aldagaia
        (uint16 *)BG_BMP_RAM(0), // Fondo nagusiaren helbidea
        images[i].bitMapLen); // Luzera (bytetan); automatikoki sortzen den aldagaia
    }
}
/*void erakutsiPrueba() {
		
    dmaCopyHalfWords(DMA_CHANNEL,
                     pruebaBitmap, // Automatikoki sortzen den aldagaia
                     (uint16 *)BG_BMP_RAM_SUB(0), // Fondo nagusiaren helbidea
                     pruebaBitmapLen); // Luzera (bytetan); automatikoki sortzen den aldagaia
}*/



/***********************2024-2025*******************************/

