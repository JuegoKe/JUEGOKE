#include "definizioak.h"

char *izenak[] = {
    "Manolo","Pablo","Carmen","Iker","Xabier","Miren","Kim","Xing", "Manito","Maeb","Cristina", "Francisco", "Adolfo", "Manueh", "Begoña", "Charo","Patxi", "Vaca", "JD", "Antonio"
};

char *abizenak[] = {
    "Escobar", "Motos", "de Mairena", "Erkizia", "Josune", "Jong Un", "Ji Ping","Fuentes", "Tuerca","Vaca", "Vance", "Carrascosa", "Recio", "Delfin", "Francisco", "Bequer", "Mirador"
};