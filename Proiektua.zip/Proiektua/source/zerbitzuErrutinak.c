// 2024-2025 ikasturtea

/*-------------------------------------
periferikoak.c
-------------------------------------*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include <stdlib.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"
#include "jokoa01.h"

#define IZENNUM 20
#define ABIZENNUM 16

int EGOERA; // Automata zein egoeratan dagoen adierazteko erabilia
int seg3;   // Hiru segundo pasatzen ote diren ikusten joateko
NAN dni[NUM_MAX_PEOPLE];

int randenrango(int min, int max) {
    return rand() % (max - min + 1) + min;
}

void clearBackground(int bgId) {
    // Obtener el mapa del fondo (pantalla principal o secundaria)
    u16 *map = (bgId == 0) ? (u16*)BG_MAP_RAM(0) : (u16*)BG_MAP_RAM_SUB(2);
    
    // Rellenar todo el mapa con el tile 0 (asumiendo que el tile 0 está vacío)
    for (int i = 0; i < 32 * 32; i++) {
        map[i] = 0;
    }
}

int save(DATA* data) {
    iprintf("\x1b[14;0HIniciando guardado..."); // Mensaje inicial
    if (fatInitDefault()) {
        iprintf("\x1b[15;0HFAT inicializado OK");
        FILE* file = fopen("/data.sav", "wb");
        if (file) {
            iprintf("\x1b[16;0HArchivo abierto OK");
            size_t bytesEscritos = fwrite(data, sizeof(DATA), 1, file);
            fclose(file); // Cierra el archivo para asegurar la escritura
            if (bytesEscritos == 1) {
                iprintf("\x1b[17;0HGuardado exitoso (%d bytes)", sizeof(DATA));
            } else {
                iprintf("\x1b[17;0HError al escribir (%d bytes)", bytesEscritos);
            }
        } else {
            iprintf("\x1b[16;0HError: No se pudo abrir archivo");
        }
    } else {
        iprintf("\x1b[15;0HError: FAT no inicializado");
    }
    return 0;
}

int load(DATA* data)
{
	 
	FILE* file = fopen("/partida.sav", "rb"); // "rb" para modo binario de lectura
    if (file) {
        size_t bytesLeidos = fread(data, sizeof(DATA), 1, file);
        if (bytesLeidos == 1) {
            
        } else {
            iprintf("\x1b[12;0HError al leer");
        }
        fclose(file);
    } else {
        iprintf("\x1b[12;0HNo se encontro archivo");
    }
}

void listakEgin()
{
 int i;
  for(i = 0; i < 5; i++)
  {
    strncpy(betatuListaIzena[i], izenak[randenrango(0, IZENNUM)], sizeof(betatuListaIzena[i]) - 1);
    betatuListaIzena[i][sizeof(betatuListaIzena[i]) - 1] = '\0'; // Asegura terminación
    strncpy(betatuListaAbizena[i], abizenak[randenrango(0, ABIZENNUM)], sizeof(betatuListaAbizena[i]) - 1);
    betatuListaAbizena[i][sizeof(betatuListaAbizena[i]) - 1] = '\0';
  }
}

void etenZerbErrutEzarri()
{
// HAU BETE
	
}



NAN sortuDNIBerriBat()
{
  
NAN berria;
berria.ondo = true;
berria.izena = izenak[randenrango(0, IZENNUM)];
berria.abizena = abizenak[randenrango(0, ABIZENNUM)];
berria.sexua = randenrango(0,1);
berria.image = randenrango(0, 7);

berria.iraunaldia[2] = randenrango(2026, 2050);
berria.iraunaldia[1] = randenrango(1, 12);
berria.iraunaldia[0] = randenrango(1, 28);

berria.jaioteguna[2] = randenrango(1956, 2006);
berria.jaioteguna[1] = randenrango(1, 12);
berria.jaioteguna[0] = randenrango(1, 28);

berria.pertsonaia = randenrango(0, 7);
berria.numero = 34345739;

return berria;
}

void sartuBetListan(char izena[20], char abizena[20])
{
    int i = randenrango(0, 9);

    strncpy(betatuListaIzena[i], izena, sizeof(betatuListaIzena[i]) - 1);
    betatuListaIzena[i][sizeof(betatuListaIzena[i]) - 1] = '\0'; // Asegura terminación

    strncpy(betatuListaAbizena[i], abizena, sizeof(betatuListaAbizena[i]) - 1);
    betatuListaAbizena[i][sizeof(betatuListaAbizena[i]) - 1] = '\0';
}

void erroreakJARRI()
{
    int i, p;
    int lista = 0;
    int selekzioa;
    for(i = 0; i < 6 + eguna;i++)
    {
       selekzioa = randenrango(0, 3);
       do{
       p = randenrango(0, NUM_MAX_PEOPLE - 5 + eguna);
       }while(dni[p].ondo == false);
       dni[p].ondo = false;
       switch (selekzioa)
       {
       case 0:
        if(lista < 4)
        {
        lista++;
        sartuBetListan(dni[p].izena, dni[p].abizena);
        }
        else{
            dni[p].ondo = true;
        }
        break;
       case 1:
        dni[p].iraunaldia[2] = 2024 - randenrango(0, 34);
        break;
       case 2:
        dni[p].jaioteguna[2] = 2010 + randenrango(0, 15);
        break;
       case 3:
        dni[p].numero = dni[p].numero + randenrango(1, 99)*1000000000;
        break;
       default:
        break;
       }
    }
}

void hasieratuEguna()
{
int i;
eguna++;
puntuacion = 0;
for(i = 0; i < NUM_MAX_PEOPLE - 5 + eguna; i++)
{
dni[i] = sortuDNIBerriBat();
}
erroreakJARRI();
listakEgin();
}







void printLista()
{
    consoleClear();
    iprintf("\x1b[10;5H-%s %s", betatuListaIzena[0], betatuListaAbizena[0]);
    iprintf("\x1b[11;5H-%s %s", betatuListaIzena[1], betatuListaAbizena[1]);
    iprintf("\x1b[12;5H-%s %s", betatuListaIzena[2], betatuListaAbizena[2]);
    iprintf("\x1b[13;5H-%s %s", betatuListaIzena[3], betatuListaAbizena[3]);
    iprintf("\x1b[14;5H-%s %s", betatuListaIzena[4], betatuListaAbizena[4]);

}

void printDNI(int i)
{
    consoleClear();
    iprintf("\x1b[8;18H%s", dni[i].izena ); // izena
    iprintf("\x1b[6;19H%s", dni[i].abizena); //abizena
    iprintf("\x1b[14;20H%d %d %d",dni[i].jaioteguna[0],dni[i].jaioteguna[1],dni[i].jaioteguna[2] );//jaioteguna 
    iprintf("\x1b[12;20H%d %d %d",dni[i].iraunaldia[0],dni[i].iraunaldia[1],dni[i].iraunaldia[2] );//iraunaldia
    if(dni[i].sexua == 0)
    {
        iprintf("\x1b[10;18HM" );//M
    }
    else
    {
        iprintf("\x1b[10;18HF" );//F
    }
    iprintf("\x1b[4;17H%d",dni[i].numero);
    

}






    

/***********************2024-2025*******************************/

