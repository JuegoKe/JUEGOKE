// 2024-2025 ikasturtea

/*---------------------------------------------------------------------------------
Kode hau garatu da dovotoren "Simple sprite demo" adibidean eta Jaeden Ameronen beste
adibide batean oinarrituta.
---------------------------------------------------------------------------------*/

#include <nds.h> 		// NDS-rako garatuta dagoen liburutegia
#include <stdio.h>		// C-ko liburutegi estandarra sarrera eta irteerako funtzioak definitzen dituena
#include <stdlib.h>		// C-ko liburutegi estandarra memoria erreserbak eta zenbaki bihurketak egiteko
#include <unistd.h>		// Sistema eragileen arteko bateragarritasuna ziurtatzeko liburutegia

// Guk garatutako fitxategiak
	
#include "definizioak.h"
#include "periferikoak.h"
#include "zerbitzuErrutinak.h"
#include "fondoak.h"
#include "jokoa01.h"
#include "grafikoak.h"

int denb; // denbora neurtzen joateko; baloratu ea beharrezkoa den
int tekla = 0;
void jokoa01()
{	
	// Aldagai baten definizioa
	
	

	EGOERA=ZAI;
	DATA data;
	
		// Hau 22 lerroan eta 5 zutabean hasiko da idazten.
													//Aldagai baten idatzi nahi izanez gero, %d komatxoen barruan eta 
													 //komatxoen kanpoan aldagaiaren balioa.
	
	
	//******************************2.JARDUERAN************************************************//
	// ORDEN HONETAN ZEREGIN HAUEK EGITEA GOMENDATZEN DA:
	// Teklatua konfiguratu behar da.	
	//konfiguratuTeklatua();
	// Tenporizadorea konfiguratu behar da.
	//konfiguratuTenporizadorea();
	// Etenen zerbitzu errutinak ezarri behar dira.
	
	// Teklatuaren etenak baimendu behar dira.
	//TekEtenBaimendu();
	// Tenporizadorearen etenak baimendu behar dira.
	//DenbEtenBaimendu();
	// Etenak baimendu behar dira.
	//EtenakBaimendu();
	//***************************************************************************************//
    while (1)
	{
		if(EGOERA == EXIT)
		{
			break;
		}
		switch (EGOERA)
		{
		case ZAI:
			EGOERA = Menu(&data);
			break;
		case OPTIONS:
		    EGOERA = Options();
			break;
		case JOKOA:
		    EGOERA = jokoa();
			break;
			case TUTORIAL:
		    EGOERA = Tutorial();
			break;
		default:
			break;
		}
		swiWaitForVBlank();
	}
	
	

	TekEtenGalarazi();
	DenbEtenGalarazi();
	EtenakGalarazi();
	// Bukaeran etenak galarazi.
}
int jokoa()
{
	while(1)
	{
		tekla = TeklaDetektatu();
		
	if(EGOERA == JOKOA)
	{
      if(tekla == R)
	  {
         EGOERA = LISTA;
	  }
	  if(tekla == L)
	  {
		EGOERA = DNI;
	  }
	}
	if(EGOERA == DNI)
	{
			
	}
	if(EGOERA == LISTA)
	{

	}
    }
	return JOKOA;
}
int Options()
{
	erakutsiMenua();
	while (1)
	{
		iprintf("\x1b[23;5HOptions es esto");
		tekla = SakatutakoTekla();
		if(tekla == B)
		{
			
				consoleClear();
				return ZAI;
				break;
			
		}
	}
	
}
int Menu(DATA* data)
{
	int framecounter = 0;
	int i = 1;
	touchPosition touch;
	//iprintf("\x1b[2;5H1:JOKOA");
	
	//iprintf("\x1b[6;5H3:EXIT");
	//iprintf("\x1b[23;5HAldagai proba. Balioa=%d", i);
	erakutsiMenua();
	erakutsiAtea();
	iprintf("\x1b[5;13HJOKOA");
	iprintf("\x1b[9;13HTUTORIAL");
	iprintf("\x1b[12;13HOPTIONS");
	iprintf("\x1b[16;13HEXIT");
	
	
	while (1)
	{	
		
		scanKeys();
		touchRead(&touch);
		//iprintf("\x1b[23;5HOptions %d es esto", tekla);
		if(keysHeld() & KEY_TOUCH)
		{
			consoleClear();
			//iprintf("\x1b[12;0HTocando en: X=%d, Y=%d", touch.px, touch.py);
			if(touch.px > 51 && touch.px < 202 && touch.py >30 && touch.py < 52)
			{
				consoleClear();

				return JOKOA;
				break;
			}
			else if(touch.px > 51 && touch.px < 202 && touch.py >50 && touch.py < 82)
			{
				
				return TUTORIAL;
				break;
			}
			else if(touch.px > 51 && touch.px < 202 && touch.py >90 && touch.py < 110)
			{
				consoleClear();
				return OPTIONS;
				break;
			}
			else if(touch.px > 51 && touch.px < 202 && touch.py >120 && touch.py < 145)
			{
				consoleClear();
				return EXIT;
			}

		}
		
		/*************************************1.JARDUERAN**************************************/
		// ZAI egoeran dagoela, hemen teklatuaren inkesta egin, sakatu den tekla pantailaratu, eta START
		// sakatzean egoera aldatu
		if(TeklaDetektatu() == 1)
		{
			
	    tekla = SakatutakoTekla();
		if(tekla == A)//Dependiendo de la selekzion mediante las flechas de arriba y abajo se selekziona la instancia del juego
		{
			if(i == 1)
			{
				consoleClear();
				return JOKOA;
				break;
			}
			if(i == 2)
			{
				consoleClear();
				return OPTIONS;
				break;
			}
			if(i == 3)
			{
				consoleClear();
				
				data->i = 5;
				save(&data);
				data->i = 8;
				
			}
			if(i == 4)
			{
				consoleClear();
				return EXIT;
				break;
			}
			if(i == 5)
			{
				consoleClear();
				load(&data);
				iprintf("\x1b[15;0HRecuperando dato%d", data->i);
			}
		}
		if(tekla == GORA&&framecounter >= 35) //Para que el numero de selekzion no se sobreaumente o sobrebaje hay un limite donde el frame counter debe superar 35 asi dejando un espacio entre pulsacion y pulsacion
		{
			consoleClear();
			if(i != 5)
			{
			i++;
			}
			else{i = 1;}
			iprintf("\x1b[2;5H1:JOKOA");
			iprintf("\x1b[4;5H2:OPTIONS");
			iprintf("\x1b[6;5H3:EXIT");
			iprintf("\x1b[23;5HAldagai proba. Balioa=%d", i);
			framecounter = 0;
		}
		if(tekla == BEHERA&&framecounter >= 35)
		{
			consoleClear();
			if(i != 1)
			{
			i--;
			}
			else{i = 5;}
			iprintf("\x1b[2;5H1:JOKOA");
			iprintf("\x1b[4;5H2:OPTIONS");
			iprintf("\x1b[6;5H3:EXIT");
			iprintf("\x1b[23;5HAldagai proba. Balioa=%d", i);
			framecounter = 0;
		}
	    }
		framecounter++;
		swiWaitForVBlank();
	}
			
	
}

int Tutorial()
{
	int framecounter = 0;
	bool entrado = false;
	erakutsiTutoPag1();
	while(1)
	{
	
	if(TeklaDetektatu())
	{
  tekla = SakatutakoTekla();

  
  //DNItutorial();
  if(tekla == R && !entrado && framecounter == 3)
  {
	
	erakutsiTutoPag2();
	entrado = true;
	tekla = 0;
	framecounter = 0;
  }
  
  if(entrado && tekla == R && framecounter == 3)
  {
	return OPTIONS;
	framecounter = 0;
  }
  framecounter++;
  swiWaitForVBlank();
  }
  
}



}



/***********************2024-2025*******************************/

