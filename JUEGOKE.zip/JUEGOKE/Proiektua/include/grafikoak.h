// 2024-2025 ikasturtea

/* Bideo sistemaren definizioa */
extern void hasieratuBideoa();
extern void GrafikoakHasieratu();
extern void hasieratuFondoak();


/* Spriteen memoria hasieratu */
extern void initSpriteMem();

extern void HasieratuGrafikoakSpriteak();

/***********************2024-2025*******************************/

