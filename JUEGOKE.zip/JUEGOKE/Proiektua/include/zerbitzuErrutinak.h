// 2024-2025 ikasturtea

/*-------------------------------------
zerbitzuErrutinak.h
-------------------------------------*/

extern void tekEten ();
extern void tenpEten();
extern void etenZerbErrutEzarri();
extern int save();
extern int load();
/***********************2024-2025*******************************/

