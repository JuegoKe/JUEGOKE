// 2024-2025 ikasturtea

/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiAtea();
extern void erakutsiAteaIrekita();
extern void erakutsiMenua();
/***********************2024-2025*******************************/

