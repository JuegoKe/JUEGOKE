// 2024-2025 ikasturtea

/*-------------------------------------
periferikoak.c
-------------------------------------*/

#include <nds.h>
#include <fat.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"

int EGOERA; // Automata zein egoeratan dagoen adierazteko erabilia
int seg3;   // Hiru segundo pasatzen ote diren ikusten joateko

int save(DATA* data) {
    iprintf("\x1b[14;0HIniciando guardado..."); // Mensaje inicial
    if (fatInitDefault()) {
        iprintf("\x1b[15;0HFAT inicializado OK");
        FILE* file = fopen("/data.sav", "wb");
        if (file) {
            iprintf("\x1b[16;0HArchivo abierto OK");
            size_t bytesEscritos = fwrite(data, sizeof(DATA), 1, file);
            fclose(file); // Cierra el archivo para asegurar la escritura
            if (bytesEscritos == 1) {
                iprintf("\x1b[17;0HGuardado exitoso (%d bytes)", sizeof(DATA));
            } else {
                iprintf("\x1b[17;0HError al escribir (%d bytes)", bytesEscritos);
            }
        } else {
            iprintf("\x1b[16;0HError: No se pudo abrir archivo");
        }
    } else {
        iprintf("\x1b[15;0HError: FAT no inicializado");
    }
    return 0;
}

int load(DATA* data)
{
	 
	FILE* file = fopen("/partida.sav", "rb"); // "rb" para modo binario de lectura
    if (file) {
        size_t bytesLeidos = fread(data, sizeof(DATA), 1, file);
        if (bytesLeidos == 1) {
            iprintf("\x1b[12;0HCargado: %d", data->i);
        } else {
            iprintf("\x1b[12;0HError al leer");
        }
        fclose(file);
    } else {
        iprintf("\x1b[12;0HNo se encontro archivo");
    }
}

void tekEten ()
{
if (EGOERA == ITXITA)
{	
	if (SakatutakoTekla()==A)
	{
		EGOERA=IREKITA;
		iprintf("\x1b[13;5HPasa diren segunduak=0");
		erakutsiAteaIrekita();
		seg3=0;
		ErakutsiErronboa(1, 5, 5);
		ErakutsiErronboHandia(2, 100, 100);
	}
}
}

void tenpEten()
{
	static int tik=0;
	static int seg=0;
	

if (EGOERA!=ZAI)
{
	tik++; 
	if (tik==5)
	{
		seg++;
		iprintf("\x1b[13;5HPasa diren segunduak=%d", seg);
		tik=0;
		if (EGOERA == IREKITA)
		{
			seg3++;
			if (seg3==3)
			{
				erakutsiAtea();
				seg3=0;
				EGOERA=ITXITA;
				EzabatuErronboa(1, 5, 5);
				EzabatuErronboHandia(2, 100, 100);
			}
		}
				
	}
}
	
}

void etenZerbErrutEzarri()
{
// HAU BETE
	
}

/***********************2024-2025*******************************/

