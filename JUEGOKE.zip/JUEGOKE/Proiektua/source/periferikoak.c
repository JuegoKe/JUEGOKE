// 2024-2025 ikasturtea

/*-------------------------------------
periferikoak.c
-------------------------------------*/

#include <nds.h>
#include <stdio.h>
#include "definizioak.h"


 // Sakatutako tekla gordetzeko aldagaia; baloratu ea behar den



int TeklaDetektatu() 
{
	// TRUE itzultzen du teklaren bat sakatu dela detektatzen badu
	if ((~TEKLAK_DAT & 0x03ff)!=0) return 1;
	else return 0;

}

int SakatutakoTekla() 
{
    // Sakatutako teklaren balioa itzultzen du: A=0; B=1; SELECT=2; START=3; ESKUBI=4; EZKER=5;
    // GORA=6; BEHERA=7; R=8; L=9;

    switch (TEKLAK_DAT)  // Sin la inversión (~) si no es necesario
    {
    case 0x3FE:  // A
        return A;
        break;
    case 0x3FD:  // B
        return B;
        break;
    case 0x3FB:  // SELECT
        return SELECT;
        break;
    case 0x3F7:  // START
        return START;
        break;
    case 0x3EF:  // ESKUBI
        return ESKUBI;
        break;
    case 0x3DF:  // EZKER
        return EZKER;
        break;
    case 0x3BF:  // GORA
        return GORA;
        break;
    case 0x37F:  // BEHERA
        return BEHERA;
        break;
    case 0x2FF:  // R
        return R;
        break;
    case 0x1FF:  // L
        return L;
        break;
    default:
        return -1;  // Si no coincide con ninguna tecla, retornar -1 o un valor adecuado
        break;
    }
}


// Configuración del teclado (teklatua)
void konfiguratuTeklatua(int TEK_konf)
{
    // Cambiar el registro de control del teclado según el valor del parámetro.
    // El parámetro TEK_konf define qué bits se activan en el registro de control.
    // La configuración se realiza modificando los registros S/I del teclado.
    // Asumimos que el valor TEK_konf es un valor de 8 bits.

    TEKLAK_KNT = TEK_konf;  // Asigna el valor de TEK_konf al registro de control del teclado.
}

// Configuración del temporizador (tenporizadorea)
void konfiguratuTenporizadorea(int Latch, int TENP_konf)
{
    // Configuración del temporizador, con Latch y TENP_konf que determinan el comportamiento del temporizador.
    // Latch define el valor inicial del temporizador y TENP_konf configura su comportamiento.
    // La configuración se realiza manipulando los registros S/I del temporizador.

    DENB0_KNT = Latch;    // Cargar valor de latch en el temporizador 0 (o el temporizador correspondiente).
    DENB0_DAT = TENP_konf;  // Cargar configuración del temporizador en el registro de control.
}

// Habilitar interrupciones del teclado
void TekEtenBaimendu()
{
    // Deshabilitar todas las interrupciones antes de modificar el estado.
    IME = 0;

    // Aquí se debe configurar y habilitar la interrupción del teclado.
    // Para ello, aseguramos que el registro de interrupciones del teclado esté configurado correctamente.

    // Activamos la interrupción del teclado.
    IF = 0x0002;  // Limpiar bandera de interrupción de teclado.
    IE |= 0x0002;  // Habilitar la interrupción del teclado.

    IME = 1;  // Rehabilitar interrupciones globales.
}

// Deshabilitar interrupciones del teclado
void TekEtenGalarazi()
{
    // Deshabilitar todas las interrupciones antes de modificar el estado.
    IME = 0;

    // Deshabilitar la interrupción del teclado.
    IF = 0x0002;  // Limpiar bandera de interrupción de teclado.
    IE &= ~0x0002;  // Deshabilitar la interrupción del teclado.

    IME = 1;  // Rehabilitar interrupciones globales.
}

// Habilitar interrupciones del temporizador
void DenbEtenBaimendu()
{
    // Deshabilitar todas las interrupciones antes de modificar el estado.
    IME = 0;

    // Aquí se debe configurar y habilitar la interrupción del temporizador (Timer0).
    // Limpiar la bandera de interrupción del temporizador.
    IF = 0x0001;  // Limpiar bandera de interrupción del temporizador 0.
    IE |= 0x0001;  // Habilitar la interrupción del temporizador 0.

    IME = 1;  // Rehabilitar interrupciones globales.
}

// Deshabilitar interrupciones del temporizador
void DenbEtenGalarazi()
{
    // Deshabilitar todas las interrupciones antes de modificar el estado.
    IME = 0;

    // Deshabilitar la interrupción del temporizador.
    IF = 0x0001;  // Limpiar bandera de interrupción del temporizador 0.
    IE &= ~0x0001;  // Deshabilitar la interrupción del temporizador 0.

    IME = 1;  // Rehabilitar interrupciones globales.
}

// Iniciar reloj del sistema
void ErlojuaMartxanJarri()
{
    // Aquí puedes activar el reloj o temporizadores que quieras controlar.
    // Por ejemplo, si estás utilizando un temporizador de la DS, podrías configurarlo.
    DENB0_KNT = IME_ENABLE | 0x400; // Ejemplo de configuración de temporizador 0.
}

// Detener reloj del sistema
void ErlojuaGelditu()
{
    // Desactivar el temporizador o reloj del sistema.
    DENB0_KNT = 0;  // Apagar temporizador 0.
}
